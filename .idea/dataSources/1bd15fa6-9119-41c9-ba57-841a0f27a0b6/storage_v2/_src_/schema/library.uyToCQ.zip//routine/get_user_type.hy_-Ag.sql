create
    definer = root@localhost procedure get_user_type(IN p_tag varchar(100), OUT type int)
begin
    select user_type_id into type from user where tag = p_tag;
end;

