create
    definer = root@localhost procedure user_system_data(IN p_tag varchar(100), OUT p_username varchar(20),
                                                        OUT p_activateDate char(20))
begin
    select username INTO @user from user where tag = p_tag;
    IF @user is not NULL then
        select username , activationDate into @name , @date from user where userName = @user;
        set p_username = @name;
        set p_activateDate = @date;
    end if;

end;

