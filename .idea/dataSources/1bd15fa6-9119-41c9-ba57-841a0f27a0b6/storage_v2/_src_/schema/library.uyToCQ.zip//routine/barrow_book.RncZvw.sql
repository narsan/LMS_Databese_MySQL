create
    definer = root@localhost procedure barrow_book(IN p_tag varchar(100), IN book_id_to_barrow int,
                                                   OUT error_message varchar(300))
begin
    declare book_deadline date;
    select username , Withdrawal , user_type_id INTO @user , @money, @typeID from user where tag = p_tag;
    IF @user is not NULL then
        select bookID , Price , stock , bookCategoryID into @id , @book_price , @num_of_book , @cat_id from book where bookID = book_id_to_barrow;
        if @typeID = 4 and @cat_id = 2 then
            set error_message = 'you do not have access to this category';
            rollback;
        elseif @typeID = 5 and (@cat_id = 2 or  @cat_id = 3) then
            set error_message = 'you do not have access to this category';
            rollback;
        else
            if @money - (5/100)*@book_price > 0 and @num_of_book - 1 > 0 then
                SET SQL_SAFE_UPDATES=0;
                update book set stock = stock -1 where bookID = book_id_to_barrow;
                commit;
                update user set Withdrawal = @money - (5/100)*@book_price where userName = @user;
                commit;
                set book_deadline = curdate()+ interval 10 day;
                set error_message = concat('you have the book until ',book_deadline ,' please return it on time');
                insert into barrowstatus (userName, bookID, ReceivedDate, Deadline , history)
                values(@user , @id , curdate(), book_deadline , error_message);
                commit;
            elseif @money - (5/100)*@book_price < 0 then
                set error_message = 'you do not have enough credit';
                insert into barrowstatus (userName, bookID, history)
                values(@user , @id , error_message);
                commit;
            elseif @num_of_book - 1 < 0 then
                set error_message = 'book is not available in the stuck';
                insert into barrowstatus (userName, bookID, history)
                values(@user , @id , error_message);
                commit;
            end if;
        end if;
    end if;
end;

