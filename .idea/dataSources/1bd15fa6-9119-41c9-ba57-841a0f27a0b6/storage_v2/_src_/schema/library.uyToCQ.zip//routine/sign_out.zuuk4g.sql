create
    definer = root@localhost procedure sign_out(IN p_tag varchar(100))
begin
    SET SQL_SAFE_UPDATES=0;
    update user set tag =  null where tag = p_tag;
    commit;
end;

