create
    definer = root@localhost procedure user_personal_data(IN p_tag varchar(100), OUT p_FirstName char(50),
                                                          OUT p_LastName char(50), OUT p_PhoneNumber varchar(12),
                                                          OUT p_Address varchar(200), OUT customerTypeID char(20),
                                                          OUT p_Withdrawal int)
begin
    select username INTO @user from user where tag = p_tag;
    IF @user is not NULL then
        select FirstName , LastName , PhoneNumber , Address , user_type_id , Withdrawal INTO @firs , @last , @num , @adrs , @typeID , @count
        from user where userName = @user;
        select user_type into @type from usertype where user_type_id = @typeID;
        set p_FirstName = @firs;
        set p_LastName = @last;
        set p_PhoneNumber = @num;
        set p_Address = @adrs;
        set customerTypeID = @type;
        set p_Withdrawal = @count;
    end if;

end;

