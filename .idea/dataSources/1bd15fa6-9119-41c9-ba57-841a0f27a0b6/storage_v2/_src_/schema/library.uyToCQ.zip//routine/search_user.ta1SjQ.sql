create
    definer = root@localhost procedure search_user(IN p_tag varchar(100), IN inp_userName varchar(20),
                                                   IN inp_LastName varchar(50), IN inp_limit int, IN inp_offset int,
                                                   OUT error_message varchar(300))
begin
    begin
    select userName,user_type_id into @user , @id from user where p_tag = tag;
    if @user is not null then
        if @id = 1 or @id = 2 then
            select ID , userName ,activationDate , FirstName, LastName,PhoneNumber , Address ,user_type,Withdrawal
            from user join usertype u on user.user_type_id = u.user_type_id
            where userName is null or userName = inp_userName or LastName is null or LastName = inp_LastName order by FirstName
            limit inp_limit offset inp_offset;
        else
            set error_message = 'you do not have access to this field';
            rollback ;
        end if;
    else
        set error_message = 'please log in first';
        rollback;
    end if;
end;


end;

