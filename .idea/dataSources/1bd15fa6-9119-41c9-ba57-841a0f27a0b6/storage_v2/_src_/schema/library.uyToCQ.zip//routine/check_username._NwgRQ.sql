create
    definer = root@localhost procedure check_username(IN p_userName varchar(20), OUT error_message varchar(300))
begin
    SET @User_exists = 0;
    SELECT 1 INTO @User_exists
    FROM user
    WHERE username = p_userName;
    SELECT @User_exists;
    IF @User_exists != 1 then
        IF CHAR_LENGTH(p_userName) < 5 then
            set  error_message = 'An error has occurred, userName does not have enough character';
        end if;
    else
        set error_message = 'user already exists';
    end if;

end;

