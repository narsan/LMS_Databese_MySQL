create
    definer = root@localhost procedure create_account(IN p_userName varchar(20), IN p_password varchar(255),
                                                      IN p_activateDate char(20), IN p_FirstName char(50),
                                                      IN p_LastName char(50), IN p_PhoneNumber varchar(12),
                                                      IN p_Address varchar(200), IN p_userTypeID int,
                                                      OUT p_tag varchar(100), OUT error_message varchar(300))
begin
#     ALTER TABLE customeraccount
#     ADD CONSTRAINT CHECK (p_password like '%[0-9]%' AND (p_password like '%[a-z]%' or p_password like '%[A-Z]%'));
    insert into user(username, password, activationdate, firstname, lastname, phonenumber, address, user_type_id)
    values (p_userName, MD5(p_password), p_activateDate, p_FirstName, p_LastName, p_PhoneNumber, p_Address, p_userTypeID);
    commit;
    SET SQL_SAFE_UPDATES=0;
    update user set tag =  md5(concat(p_userName,p_password,CURRENT_TIME)) where userName = p_userName;
#     values (p_userName ,concat(substring(p_userName,3,3),substring(p_password , 1 , 2),CURRENT_TIME));
    commit;
    select tag INTO @p_tag from user where username = p_userName;
    set p_tag = @p_tag;
    set error_message = 'you sign up successfully';
end;

