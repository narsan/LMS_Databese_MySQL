create
    definer = root@localhost procedure increase_credit(IN p_tag varchar(100), IN credit int, OUT error_message varchar(100))
begin
     SET SQL_SAFE_UPDATES=0;
     update user set Withdrawal = Withdrawal + credit where tag = p_tag;
     set error_message = 'credit updated';
     commit;
     IF credit < 1000 Then
         set error_message = 'you entered an invalid number please try again';
         rollback ;
     end if;

end;

