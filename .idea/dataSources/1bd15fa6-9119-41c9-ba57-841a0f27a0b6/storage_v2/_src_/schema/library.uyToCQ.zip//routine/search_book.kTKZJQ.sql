create
    definer = root@localhost procedure search_book(IN book_title char(100), IN book_Author char(20),
                                                   IN book_publish_date date, IN book_edition int)
begin
     select bookID , Title, Volume, bookCategory , NumberOfPages, Price, Author, edition, publish_date, PublisherName, stock
     from  book join bookcategory b on book.bookCategoryID = b.bookCategoryID
     where (book_title is null or book_title = Title ) and (book_Author is null or book_Author = Author)
     and (book_publish_date is null or book_publish_date = publish_date) and (book_edition = 0 or book_edition = edition)
     order by book.Title;

end;

