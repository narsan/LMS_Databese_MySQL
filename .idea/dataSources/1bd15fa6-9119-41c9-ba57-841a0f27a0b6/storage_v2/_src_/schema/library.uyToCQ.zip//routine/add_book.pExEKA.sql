create
    definer = root@localhost procedure add_book(IN p_tag varchar(100), IN inp_Volume smallint, IN inp_Title char(100),
                                                IN inp_bookCategoryID int, IN inp_NumberOfPages int, IN inp_Price int,
                                                IN inp_Author char(20), IN inp_edition int, IN inp_publish_date date,
                                                IN inp_PublisherName char(50), OUT error_message varchar(300))
begin
    select userName,user_type_id into @user , @id from user where p_tag = tag;
    if @user is not null then
        if @id = 1 or @id = 2 then
            select 1 into @book_available from book where Volume = inp_Volume and Title = inp_Title
            and bookCategoryID = inp_bookCategoryID and NumberOfPages = inp_NumberOfPages and Price = inp_Price
            and Author = inp_Author and edition = inp_edition and publish_date = inp_publish_date and PublisherName = inp_PublisherName;
            if @book_available = 1 then
                update book set stock = stock + 1 where Title = inp_Title;
                set error_message = 'book updated on stock';
            else
                insert into book(Volume, Title, bookCategoryID, NumberOfPages, Price, Author, edition, publish_date, PublisherName, stock)
                values (inp_Volume , inp_Title , inp_bookCategoryID , inp_NumberOfPages , inp_Price , inp_Author , inp_edition , inp_publish_date , inp_PublisherName , 1);
                commit;
                set error_message = 'book added to library';
            end if;
        else
            set error_message = 'you do not have access to this field';
            rollback ;
        end if;
    else
        set error_message = 'please log in first';
        rollback;
    end if;
end;

