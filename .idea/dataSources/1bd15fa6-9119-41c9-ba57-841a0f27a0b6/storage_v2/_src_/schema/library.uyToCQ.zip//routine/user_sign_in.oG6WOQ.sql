create
    definer = root@localhost procedure user_sign_in(IN p_userName varchar(20), IN p_password varchar(255),
                                                    OUT p_tag varchar(100), OUT error_message varchar(300))
begin
    SET @User_exists = 0;
    SELECT 1 INTO @User_exists
    FROM user
    WHERE username = p_userName;
    SELECT @User_exists;
    IF @User_exists != 1 then
        set error_message = 'username is not exist please sign up';
    else
        select 1 INTO @correct_pass from user where userName = p_userName and password = md5(p_password);
        IF @correct_pass = 1 then
            set error_message = 'successfully login';
            SET SQL_SAFE_UPDATES=0;
            update user set tag =  md5(concat(p_userName,p_password,CURRENT_TIME)) where userName = p_userName;
#     values (p_userName ,concat(substring(p_userName,3,3),substring(p_password , 1 , 2),CURRENT_TIME));
            commit;
            select tag INTO @p_tag from user where username = p_userName;
            set p_tag = @p_tag;
        else
            set error_message = 'incorrect password';
        end if;
    end if;
end;

